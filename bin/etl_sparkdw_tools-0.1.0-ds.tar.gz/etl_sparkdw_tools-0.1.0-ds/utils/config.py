class Config:
    """description of class"""
    IsSparkDataBrick=False
    DATABASE_HOSTNAME = 'localhost'
    DATABASE_PORT = 1433
    DATABASE_NAME = 'SparkDW'
    DATABASE_USERNAME = 'spark'
    DATABASE_PASSWORD = 'Monday12'
    DATABASE_ENCRYPT = 'true'
